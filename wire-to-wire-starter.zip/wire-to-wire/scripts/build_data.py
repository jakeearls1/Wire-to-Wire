#!/usr/bin/env python3
"""Build Wire to Wire team/era player pools from SABR Lahman CSV files.

Expected input directory contains:
  Teams.csv, People.csv, Batting.csv, Pitching.csv, Appearances.csv, FieldingOFsplit.csv

Usage:
  python scripts/build_data.py --input ./lahman --output ./data/player-pools.json
"""
import argparse, csv, json, math
from collections import defaultdict
from pathlib import Path

POSITIONS = ["C","1B","2B","3B","SS","LF","CF","RF","DH","SP"]

def num(v):
    try: return float(v or 0)
    except: return 0.0

def decade(y): return f"{(int(y)//10)*10}s"

def load(path):
    with open(path, encoding="utf-8-sig", newline="") as f: return list(csv.DictReader(f))

def clamp(v,a,b): return max(a,min(b,v))

def hitter_rating(s):
    ab=max(1,s['AB']); avg=s['H']/ab; obp=(s['H']+s['BB']+s['HBP'])/max(1,s['AB']+s['BB']+s['HBP']+s['SF'])
    slg=(s['H']+s['2B']+2*s['3B']+3*s['HR'])/ab
    ops=obp+slg
    volume=min(1,s['PA']/1200)
    return round(clamp(62 + (ops-.650)*48 + volume*8, 68, 99))

def pitcher_rating(s):
    ip=max(1,s['IPouts']/3); era=9*s['ER']/ip; k9=9*s['SO']/ip; bb9=9*s['BB']/ip
    volume=min(1,ip/350)
    return round(clamp(72 + (4.5-era)*5 + (k9-5)*1.5 - max(0,bb9-3)*1.2 + volume*6, 68, 99))

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--input',required=True); ap.add_argument('--output',required=True); args=ap.parse_args()
    src=Path(args.input)
    people={r['playerID']:r for r in load(src/'People.csv')}
    teams=load(src/'Teams.csv')
    team_name={(r['teamID'],r['yearID']):r.get('name') or r['teamID'] for r in teams}

    hit=defaultdict(lambda:defaultdict(float))
    for r in load(src/'Batting.csv'):
        y=int(r['yearID']); key=(r['teamID'],decade(y),r['playerID'])
        d=hit[key]
        for k in ['AB','R','H','2B','3B','HR','RBI','SB','BB','HBP','SF'] : d[k]+=num(r.get(k))
        d['PA']+=num(r.get('AB'))+num(r.get('BB'))+num(r.get('HBP'))+num(r.get('SF'))
        d['years']+=1

    pit=defaultdict(lambda:defaultdict(float))
    for r in load(src/'Pitching.csv'):
        y=int(r['yearID']); key=(r['teamID'],decade(y),r['playerID']); d=pit[key]
        for k in ['W','L','G','GS','IPouts','ER','SO','BB','SV']: d[k]+=num(r.get(k))
        d['years']+=1

    pos=defaultdict(lambda:defaultdict(float))
    for r in load(src/'Appearances.csv'):
        y=int(r['yearID']); key=(r['teamID'],decade(y),r['playerID']); d=pos[key]
        mapping={'G_c':'C','G_1b':'1B','G_2b':'2B','G_3b':'3B','G_ss':'SS','G_lf':'LF','G_cf':'CF','G_rf':'RF','G_dh':'DH'}
        for col,p in mapping.items(): d[p]+=num(r.get(col))

    pools=defaultdict(list)
    keys=set(hit)|set(pit)
    for key in keys:
        tid,era,pid=key; pr=people.get(pid,{})
        name=' '.join(x for x in [pr.get('nameFirst',''),pr.get('nameLast','')] if x).strip() or pid
        h=hit.get(key); p=pit.get(key); eligible=[]
        if h and h['PA']>=120:
            games=pos.get(key,{})
            eligible=[k for k,v in games.items() if v>=max(10,max(games.values() or [0])*.25)]
            if not eligible: eligible=['DH']
            if 'DH' not in eligible and h['PA']>=500: eligible.append('DH')
            rating=hitter_rating(h)
            stat=f"{h['H']/max(1,h['AB']):.3f} AVG · {int(h['HR'])} HR · {int(h['RBI'])} RBI"
            pools[(tid,era)].append({'id':pid,'name':name,'positions':eligible,'rating':rating,'stat':stat,'type':'hitter'})
        if p and p['GS']>=8:
            rating=pitcher_rating(p); ip=p['IPouts']/3; era_v=9*p['ER']/max(1,ip)
            pools[(tid,era)].append({'id':pid,'name':name,'positions':['SP'],'rating':rating,'stat':f"{era_v:.2f} ERA · {int(p['SO'])} K · {int(p['W'])} W",'type':'pitcher'})

    out=[]
    for (tid,era),players in sorted(pools.items()):
        # Deduplicate same player hitter/pitcher entry unless true two-way value matters; keep stronger.
        best={}
        for p in players:
            k=(p['id'],tuple(p['positions']))
            if k not in best or p['rating']>best[k]['rating']: best[k]=p
        players=sorted(best.values(),key=lambda x:(-x['rating'],x['name']))[:35]
        if len(players)<5: continue
        years=[int(r['yearID']) for r in teams if r['teamID']==tid and decade(r['yearID'])==era]
        display=team_name.get((tid,max(years))) if years else tid
        out.append({'teamID':tid,'team':display,'era':era,'players':players})
    Path(args.output).write_text(json.dumps({'generatedFrom':'SABR Lahman','pools':out},ensure_ascii=False,separators=(',',':')),encoding='utf-8')
    print(f"Wrote {len(out)} team-era pools to {args.output}")

if __name__=='__main__': main()
